#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ENGINE="$BASE/bin/specter"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
export SPECTER_DATA_DIR="$TMP/data"

"$ENGINE" --version | grep -Fx 'SPECTER 3.0.2-dev' >/dev/null

"$ENGINE" --engine-create 'QA Project' 'https://example.com/path' \
  BUG_BOUNTY UNCONFIRMED $'example.com\nwww.example.com' >/dev/null
PROJECT="$(find "$SPECTER_DATA_DIR/projects" -mindepth 1 -maxdepth 1 -type d -name 'qa-project-*' -print -quit)"
test -n "$PROJECT"
grep -Fx 'example.com' "$PROJECT/scope.txt" >/dev/null
grep -Fx 'www.example.com' "$PROJECT/scope.txt" >/dev/null

if "$ENGINE" --engine-create 'Bad Scope' 'https://example.com' \
  BUG_BOUNTY UNCONFIRMED 'other.example' >/dev/null 2>&1; then
  echo 'FAIL: mismatched scope was accepted' >&2
  exit 1
fi

if "$ENGINE" --engine-create 'Lab Deny' 'https://example.net' \
  JAILBREAK UNCONFIRMED '' >/dev/null 2>&1; then
  echo 'FAIL: unconfirmed JAILBREAK project was accepted' >&2
  exit 1
fi

"$ENGINE" --engine-create 'Lab Allowed' 'https://example.net' \
  JAILBREAK AUTHORIZED '' >/dev/null

# A symlinked scope must be rejected by the engine itself as defense in depth.
printf '%s\n' 'example.com' > "$TMP/outside-scope.txt"
rm -f "$PROJECT/scope.txt"
ln -s "$TMP/outside-scope.txt" "$PROJECT/scope.txt"
PROJECT_NAME="$(basename "$PROJECT")"
if "$ENGINE" --engine-scan "$PROJECT_NAME" UNCONFIRMED >/dev/null 2>&1; then
  echo 'FAIL: symlinked scope was accepted' >&2
  exit 1
fi

echo 'ENGINE_TESTS=PASS'
