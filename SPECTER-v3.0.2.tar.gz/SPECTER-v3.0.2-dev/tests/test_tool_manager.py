import importlib.util
import os
import tempfile
import unittest
from unittest.mock import patch
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'bin' / 'tool_manager.py'
TEMP = tempfile.TemporaryDirectory(prefix='specter-tools-test-')
os.environ['SPECTER_DATA_DIR'] = str(Path(TEMP.name) / 'data')
spec = importlib.util.spec_from_file_location('specter_tool_manager_test', ROOT)
tm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tm)

class ToolManagerTests(unittest.TestCase):
    def test_catalog_contains_expected_optional_tools(self):
        self.assertEqual(len(tm.CATALOG), 28)
        self.assertIn('nuclei', tm.CATALOG)
        self.assertIn('grype', tm.CATALOG)

    def test_inventory_is_read_only_and_structured(self):
        data = tm.inventory()
        self.assertEqual(len(data['tools']), 28)
        self.assertTrue(all({'name','status','method','managed','path'} <= set(x) for x in data['tools']))

    def test_manual_tools_cannot_be_installed_by_manager(self):
        with self.assertRaisesRegex(ValueError, 'manual'):
            tm.operate('trivy', 'install')

    def test_gitleaks_uses_canonical_go_module_path(self):
        self.assertEqual(tm.CATALOG['gitleaks'][1], 'github.com/zricethezav/gitleaks/v8@latest')

    def test_arjun_install_uses_python_m_pip_and_tracks_virtualenv(self):
        import venv as venv_mod
        venv_path = tm.VENVS / 'arjun'
        python_path = venv_path / 'bin' / 'python'
        calls = []
        class FakeBuilder:
            def __init__(self, **kwargs): pass
            def create(self, path):
                (path / 'bin').mkdir(parents=True, exist_ok=True)
                (path / 'bin' / 'python').write_text('fake')
        def fake_run(args, timeout=None, env=None):
            calls.append(args)
            return subprocess.CompletedProcess(args, 0, 'installed', '')
        def fake_which(name, path=None):
            if name == 'arjun' and path and str(venv_path / 'bin') in path:
                return str(venv_path / 'bin' / 'arjun')
            return None
        with patch.object(venv_mod, 'EnvBuilder', FakeBuilder), \
             patch.object(tm, '_run', side_effect=fake_run), \
             patch.object(tm.shutil, 'which', side_effect=fake_which):
            result = tm.operate('arjun', 'install')
        self.assertTrue(result['ok'])
        self.assertEqual(calls[0][:3], [str(python_path), '-m', 'pip'])
        self.assertIn('arjun', tm._manifest())

    def test_arjun_recreates_incomplete_existing_virtualenv(self):
        import venv as venv_mod
        venv_path = tm.VENVS / 'arjun'
        tm._save({})
        if venv_path.exists():
            import shutil
            shutil.rmtree(venv_path)
        venv_path.mkdir(parents=True, exist_ok=True)
        calls = []
        class FakeBuilder:
            def __init__(self, **kwargs): pass
            def create(self, path):
                (path / 'bin').mkdir(parents=True, exist_ok=True)
                (path / 'bin' / 'python').write_text('fake')
        def fake_run(args, timeout=None, env=None):
            calls.append(args)
            return subprocess.CompletedProcess(args, 0, 'installed', '')
        def fake_which(name, path=None):
            if name == 'arjun' and path and str(venv_path / 'bin') in path:
                return str(venv_path / 'bin' / 'arjun')
            return None
        with patch.object(venv_mod, 'EnvBuilder', FakeBuilder), \
             patch.object(tm, '_run', side_effect=fake_run), \
             patch.object(tm.shutil, 'which', side_effect=fake_which):
            result = tm.operate('arjun', 'install')
        self.assertTrue(result['ok'])
        self.assertEqual(calls[0][:3], [str(venv_path / 'bin' / 'python'), '-m', 'pip'])

    def test_missing_installer_executable_returns_actionable_error(self):
        from unittest.mock import patch
        with patch.object(tm.os, 'geteuid', return_value=0), \
             patch.object(tm.shutil, 'which', return_value=None), \
             patch.object(tm, '_run', side_effect=FileNotFoundError(2, 'missing', 'fake-pip')):
            with self.assertRaisesRegex(RuntimeError, 'Executable untuk instalasi'):
                tm.operate('arjun', 'install')

    def test_external_tools_cannot_be_updated_or_removed(self):
        with self.assertRaises(PermissionError):
            tm.operate('nuclei', 'update')
        with self.assertRaises(PermissionError):
            tm.operate('nuclei', 'remove')

    def test_unknown_tool_rejected(self):
        with self.assertRaisesRegex(ValueError, 'allowlist'):
            tm.operate('unknown-tool', 'install')

    def test_manager_storage_is_private(self):
        tm._save({'sample': {'method': 'go'}})
        self.assertEqual(tm.ROOT.stat().st_mode & 0o777, 0o700)
        self.assertEqual(tm.MANIFEST.stat().st_mode & 0o777, 0o600)

    def test_managed_binary_symlink_is_rejected(self):
        target = Path(TEMP.name) / 'outside-binary'
        target.write_text('do not touch')
        link = tm.BIN / 'nuclei'
        link.symlink_to(target)
        with self.assertRaisesRegex(PermissionError, 'symlink'):
            tm.operate('nuclei', 'install')
        self.assertEqual(target.read_text(), 'do not touch')
        link.unlink()

    def test_data_root_symlink_is_rejected(self):
        outside = Path(TEMP.name) / 'outside-data'
        outside.mkdir()
        original = tm.DATA_ROOT
        try:
            tm.DATA_ROOT = Path(TEMP.name) / 'linked-data'
            tm.DATA_ROOT.symlink_to(outside, target_is_directory=True)
            with self.assertRaisesRegex(PermissionError, 'symlink'):
                tm._safe_dirs()
        finally:
            tm.DATA_ROOT.unlink(missing_ok=True)
            tm.DATA_ROOT = original

    def test_apt_remove_executes_and_clears_manifest(self):
        tm._save({'sqlmap': {'method': 'apt', 'spec': 'sqlmap'}})
        completed = subprocess.CompletedProcess(['apt-get'], 0, 'removed', '')
        with patch.object(tm.os, 'geteuid', return_value=0), \
             patch.object(tm.shutil, 'which', return_value=None), \
             patch.object(tm, '_run', return_value=completed) as run:
            result = tm.operate('sqlmap', 'remove')
        self.assertTrue(result['ok'])
        self.assertEqual(run.call_args.args[0], ['apt-get', 'remove', '-y', '--', 'sqlmap'])
        self.assertNotIn('sqlmap', tm._manifest())

    def test_apt_install_runs_update_then_install_and_tracks_package(self):
        calls = []
        def fake_run(args, timeout=None, env=None):
            calls.append((args, timeout, env))
            return subprocess.CompletedProcess(args, 0, 'ok', '')
        def fake_which(name, path=None):
            if name == 'sqlmap' and path is not None:
                return str(tm.ROOT / 'fake-sqlmap')
            return None
        with patch.object(tm.os, 'geteuid', return_value=0), \
             patch.object(tm.shutil, 'which', side_effect=fake_which), \
             patch.object(tm, '_run', side_effect=fake_run):
            result = tm.operate('sqlmap', 'install')
        self.assertTrue(result['ok'])
        self.assertEqual(calls[0][0], ['apt-get', 'update'])
        self.assertEqual(calls[1][0], ['apt-get', 'install', '-y', '--no-install-recommends', '--', 'sqlmap'])
        self.assertEqual(calls[1][2]['DEBIAN_FRONTEND'], 'noninteractive')
        self.assertEqual(tm._manifest()['sqlmap']['method'], 'apt')

    def test_tool_command_runner_has_no_default_timeout(self):
        from unittest.mock import patch
        import tool_manager

        captured = {}
        def fake_subprocess_run(args, capture_output, text, timeout, check, env):
            captured["timeout"] = timeout
            return type("Result", (), {"stdout": "", "stderr": "", "returncode": 0})()

        with patch("tool_manager.subprocess.run", side_effect=fake_subprocess_run):
            tool_manager._run(["true"])
        self.assertIsNone(captured["timeout"])


if __name__ == '__main__':
    unittest.main()
