#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ARCH="$(uname -m)"
echo "DEVICE_ARCH=$ARCH"
case "$ARCH" in
  aarch64|arm64) echo 'ARM64_CHECK=PASS' ;;
  *) echo 'ARM64_CHECK=NOT_RUN (jalankan di perangkat ARM64 untuk validasi final)' ;;
esac

cd "$BASE"
python3 -m unittest discover -s tests -v
bash tests/test_engine.sh
bash -n bin/specter
python3 -m py_compile bin/specter-web bin/tool_manager.py
bash tests/test_install.sh

if command -v node >/dev/null 2>&1; then
  python3 - <<'PY'
from pathlib import Path
import re, tempfile
html = Path('bin/specter_ui.html').read_text(encoding='utf-8')
for i, script in enumerate(re.findall(r'<script[^>]*>(.*?)</script>', html, re.S), 1):
    Path(f'/tmp/specter-device-ui-{i}.js').write_text(script, encoding='utf-8')
PY
  for file in /tmp/specter-device-ui-*.js; do node --check "$file"; done
  echo 'UI_JS_SYNTAX=PASS'
else
  echo 'UI_JS_SYNTAX=SKIP (Node.js tidak tersedia)'
fi

TMP="$(mktemp -d)"
PORT="${SPECTER_SMOKE_PORT:-18769}"
SPECTER_DATA_DIR="$TMP/data" python3 "$BASE/bin/specter-web" --port "$PORT" >"$TMP/backend.log" 2>&1 &
PID=$!
cleanup() { kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; rm -rf "$TMP"; }
trap cleanup EXIT
python3 - "$PORT" <<'PY'
import json, sys, time, urllib.request
port = int(sys.argv[1])
base = f'http://127.0.0.1:{port}'
for _ in range(60):
    try:
        with urllib.request.urlopen(base + '/api/health', timeout=1) as r:
            health = json.load(r)
        break
    except Exception:
        time.sleep(.2)
else:
    raise SystemExit('HTTP_HEALTH=FAIL')
with urllib.request.urlopen(base + '/', timeout=3) as r:
    page = r.read().decode('utf-8')
    assert r.status == 200 and 'Tool Manager' in page
with urllib.request.urlopen(base + '/api/tools', timeout=3) as r:
    tools = json.load(r)['tools']
assert len(tools) == 28, len(tools)
assert health.get('version') == '3.0.2-dev', health
print('HTTP_HEALTH=PASS')
print('DASHBOARD_HTTP=PASS')
print('TOOL_INVENTORY=PASS (28 entries)')
PY

echo 'DEVICE_SMOKE=PASS'
