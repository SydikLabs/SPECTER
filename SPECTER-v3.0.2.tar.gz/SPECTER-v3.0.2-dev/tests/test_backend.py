import importlib.util
from importlib.machinery import SourceFileLoader
import json
import os
import tempfile
import unittest
from pathlib import Path


TEMP = tempfile.TemporaryDirectory(prefix="specter-v3-tests-")
os.environ["SPECTER_DATA_DIR"] = str(Path(TEMP.name) / "data")
MODULE_PATH = Path(__file__).resolve().parents[1] / "bin" / "specter-web"
loader = SourceFileLoader("specter_web_under_test", str(MODULE_PATH))
spec = importlib.util.spec_from_loader(loader.name, loader)
web = importlib.util.module_from_spec(spec)
spec.loader.exec_module(web)


class FakePool:
    def __init__(self):
        self.submitted = []

    def submit(self, fn, *args):
        self.submitted.append((fn, args))
        return object()


class BackendSafetyTests(unittest.TestCase):
    def setUp(self):
        web.JOBS.clear()
        web.POOL = FakePool()
        self.project_root = web.PROJECTS
        self.project_root.mkdir(parents=True, exist_ok=True)

    def make_project(self, name, mode, target="https://example.com", scope=None):
        folder = self.project_root / name
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "target.txt").write_text(target + "\n", encoding="utf-8")
        (folder / "mode.txt").write_text(mode + "\n", encoding="utf-8")
        (folder / "logs").mkdir(exist_ok=True)
        if scope is not None:
            (folder / "scope.txt").write_text(scope, encoding="utf-8")
        return folder

    def test_unknown_mode_rejected_before_job_creation(self):
        self.make_project("badmode", "UNKNOWN")
        with self.assertRaisesRegex(ValueError, "Mode proyek tidak dikenal"):
            web.start_scan({"project": "badmode"})
        self.assertEqual(web.JOBS, {})
        self.assertEqual(web.POOL.submitted, [])

    def test_jailbreak_requires_per_scan_confirmation(self):
        self.make_project("labdeny", "JAILBREAK")
        with self.assertRaises(PermissionError):
            web.start_scan({"project": "labdeny"})
        self.assertEqual(web.JOBS, {})
        self.assertEqual(web.POOL.submitted, [])

    def test_jailbreak_authorized_scan_queues(self):
        self.make_project("laballow", "JAILBREAK")
        result = web.start_scan({
            "project": "laballow",
            "authorization_confirmation": "I_AUTHORIZE_THIS_SCAN"
        })
        self.assertEqual(result["status"], "QUEUED")
        self.assertEqual(len(web.JOBS), 1)
        self.assertEqual(len(web.POOL.submitted), 1)

    def test_bug_bounty_scope_mismatch_rejected_before_job_creation(self):
        self.make_project("scopebad", "BUG_BOUNTY", scope="other.example\n")
        with self.assertRaises(PermissionError):
            web.start_scan({"project": "scopebad"})
        self.assertEqual(web.JOBS, {})
        self.assertEqual(web.POOL.submitted, [])

    def test_bug_bounty_exact_scope_queues(self):
        self.make_project("scopegood", "BUG_BOUNTY", scope="example.com\n")
        result = web.start_scan({"project": "scopegood"})
        self.assertEqual(result["status"], "QUEUED")
        self.assertEqual(len(web.POOL.submitted), 1)

    def test_symlink_scope_rejected(self):
        folder = self.make_project("scopelink", "BUG_BOUNTY")
        outside = Path(TEMP.name) / "outside-scope.txt"
        outside.write_text("example.com\n", encoding="utf-8")
        (folder / "scope.txt").symlink_to(outside)
        with self.assertRaises(PermissionError):
            web.start_scan({"project": "scopelink"})
        self.assertEqual(web.JOBS, {})

    def test_create_project_rejects_scope_mismatch_before_engine_call(self):
        before = list(self.project_root.iterdir())
        with self.assertRaisesRegex(ValueError, "harus tercantum dalam scope"):
            web.create_project({
                "name": "Mismatch Project",
                "target": "https://example.com",
                "mode": "BUG_BOUNTY",
                "scope": "other.example"
            })
        self.assertEqual(list(self.project_root.iterdir()), before)

    def test_active_job_limit(self):
        self.make_project("queuefull", "AUTOMATED_RESEARCH")
        for index in range(web.MAX_ACTIVE_JOBS):
            job_id = f"{index:016x}"
            web.JOBS[job_id] = {"id": job_id, "status": "QUEUED"}
        with self.assertRaisesRegex(RuntimeError, "Antrean penuh"):
            web.start_scan({"project": "queuefull"})
        self.assertEqual(len(web.JOBS), web.MAX_ACTIVE_JOBS)
        self.assertEqual(web.POOL.submitted, [])

    def test_report_evidence_excludes_raw_secret_values(self):
        folder = self.make_project("reporttest", "AUTOMATED_RESEARCH")
        (folder / "evidence").mkdir()
        (folder / "evidence" / "evidence.json").write_text(json.dumps([
            {
                "type": "AWS_ACCESS_KEY",
                "source": "gitleaks",
                "file": "src/config.py",
                "line": 42,
                "value": "RAW_SECRET_SENTINEL_123456",
                "token": "RAW_TOKEN_SENTINEL_ABC"
            },
            "RAW_STRING_SECRET_SENTINEL"
        ]), encoding="utf-8")
        (folder / "findings").mkdir()
        (folder / "findings" / "findings.json").write_text("[]", encoding="utf-8")
        api_data = web.project_data("reporttest")
        api_encoded = json.dumps(api_data)
        self.assertNotIn("RAW_SECRET_SENTINEL_123456", api_encoded)
        self.assertNotIn("RAW_TOKEN_SENTINEL_ABC", api_encoded)
        self.assertNotIn("RAW_STRING_SECRET_SENTINEL", api_encoded)
        self.assertEqual(api_data["secret_indicator_count"], 2)
        result = web.generate_reports("reporttest")
        self.assertIsNotNone(result)
        for profile in ("private", "shareable"):
            for extension in ("md", "json", "html"):
                report = (folder / "reports" / f"report-{profile}.{extension}").read_text(encoding="utf-8")
                self.assertNotIn("RAW_SECRET_SENTINEL_123456", report)
                self.assertNotIn("RAW_TOKEN_SENTINEL_ABC", report)
                self.assertNotIn("RAW_STRING_SECRET_SENTINEL", report)
                self.assertIn("AWS_ACCESS_KEY", report)
        private_json = json.loads((folder / "reports" / "report-private.json").read_text())
        self.assertEqual(private_json["secret_indicator_count"], 2)
        self.assertEqual(private_json["secret_indicators"][0]["line"], 42)
        self.assertEqual((folder / "reports" / "report-private.json").stat().st_mode & 0o777, 0o644)

    def test_shareable_redactor_handles_camel_case_and_json_text(self):
        value = {
            "apiKey": "CAMEL_SECRET_123",
            "client_secret": "CLIENT_SECRET_456",
            "note": '{"accessToken": "JSON_TOKEN_789"}',
            "url": "https://example.com/?api_token=QUERY_TOKEN_123"
        }
        redacted = web.redact_report_data(value)
        encoded = json.dumps(redacted)
        for secret in ("CAMEL_SECRET_123", "CLIENT_SECRET_456", "JSON_TOKEN_789", "QUERY_TOKEN_123"):
            self.assertNotIn(secret, encoded)
        self.assertEqual(redacted["apiKey"], "[REDACTED]")


if __name__ == "__main__":
    unittest.main(verbosity=2)
