#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin" "$TMP/backups"
printf 'OLD CLI\n' > "$TMP/bin/specter"
printf 'OLD WEB\n' > "$TMP/bin/specter-web"
printf 'OLD UI\n' > "$TMP/bin/specter_ui.html"
printf 'OLD MANAGER\n' > "$TMP/bin/tool_manager.py"
SPECTER_INSTALL_DIR="$TMP/bin" SPECTER_BACKUP_ROOT="$TMP/backups" \
  "$BASE/install.sh" >/dev/null

"$TMP/bin/specter" --version | grep -Fx 'SPECTER 3.0.2-dev' >/dev/null
python3 -m py_compile "$TMP/bin/specter-web"
test -s "$TMP/bin/specter_ui.html"
test -s "$TMP/bin/tool_manager.py"
python3 -m py_compile "$TMP/bin/tool_manager.py"
BACKUP="$(find "$TMP/backups" -mindepth 1 -maxdepth 1 -type d -print -quit)"
test -n "$BACKUP"
grep -Fx 'OLD CLI' "$BACKUP/specter" >/dev/null
grep -Fx 'OLD WEB' "$BACKUP/specter-web" >/dev/null
grep -Fx 'OLD UI' "$BACKUP/specter_ui.html" >/dev/null
grep -Fx 'OLD MANAGER' "$BACKUP/tool_manager.py" >/dev/null

echo 'INSTALLER_TESTS=PASS'

# Failure injection: a failed first commit must restore every prior file.
TMP_FAIL="$(mktemp -d)"
mkdir -p "$TMP_FAIL/bin" "$TMP_FAIL/backups" "$TMP_FAIL/wrappers"
for file in specter specter-web specter_ui.html tool_manager.py; do
  printf 'OLD %s\n' "$file" > "$TMP_FAIL/bin/$file"
done
REAL_MV="$(command -v mv)"
cat > "$TMP_FAIL/wrappers/mv" <<WRAPPER
#!/usr/bin/env bash
if [[ "\$4" == "$TMP_FAIL/bin/specter" && ! -e "$TMP_FAIL/failed-once" ]]; then
  : > "$TMP_FAIL/failed-once"
  exit 42
fi
exec "$REAL_MV" "\$@"
WRAPPER
chmod +x "$TMP_FAIL/wrappers/mv"
set +e
PATH="$TMP_FAIL/wrappers:$PATH" \
SPECTER_INSTALL_DIR="$TMP_FAIL/bin" \
SPECTER_BACKUP_ROOT="$TMP_FAIL/backups" \
  "$BASE/install.sh" >/dev/null 2>&1
FAIL_RC=$?
set -e
[[ "$FAIL_RC" -eq 42 ]]
for file in specter specter-web specter_ui.html tool_manager.py; do
  grep -Fx "OLD $file" "$TMP_FAIL/bin/$file" >/dev/null
done
rm -rf "$TMP_FAIL"
echo 'INSTALL_ROLLBACK_TESTS=PASS'
