#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
  echo "Jalankan installer sebagai root (sudo ./install.sh)." >&2
  exit 1
fi

SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST_DIR="${SPECTER_INSTALL_DIR:-/usr/local/bin}"
BACKUP_ROOT="${SPECTER_BACKUP_ROOT:-/root}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/specter-v3-install-backup-$STAMP"
INSTALL_STARTED=0
COMMITTED=0

rollback() {
  local rc=$?
  trap - ERR
  set +e
  rm -f -- "$DEST_DIR/.specter.new" "$DEST_DIR/.specter-web.new" "$DEST_DIR/.specter_ui.html.new" "$DEST_DIR/.tool_manager.py.new"

  if [[ "$INSTALL_STARTED" == 1 && "$COMMITTED" != 1 ]]; then
    echo "[!] Instalasi gagal. Memulihkan file sebelumnya..." >&2
    for file in specter specter-web specter_ui.html tool_manager.py; do
      if [[ -e "$BACKUP_DIR/$file" || -L "$BACKUP_DIR/$file" ]]; then
        rm -f -- "$DEST_DIR/$file"
        cp -a -- "$BACKUP_DIR/$file" "$DEST_DIR/$file" || echo "[!] Gagal memulihkan: $file" >&2
      else
        rm -f -- "$DEST_DIR/$file"
      fi
    done
  fi
  exit "$rc"
}
trap rollback ERR

for file in "$SOURCE_DIR/bin/specter" "$SOURCE_DIR/bin/specter-web" "$SOURCE_DIR/bin/specter_ui.html" "$SOURCE_DIR/bin/tool_manager.py"; do
  [[ -f "$file" ]] || { echo "File sumber tidak ditemukan: $file" >&2; exit 1; }
done
bash -n "$SOURCE_DIR/bin/specter"
python3 -c 'from pathlib import Path; import sys; compile(Path(sys.argv[1]).read_text(), sys.argv[1], "exec")' "$SOURCE_DIR/bin/specter-web"
python3 -m py_compile "$SOURCE_DIR/bin/tool_manager.py"

mkdir -p "$DEST_DIR" "$BACKUP_DIR"

for file in specter specter-web specter_ui.html tool_manager.py; do
  if [[ -e "$DEST_DIR/$file" ]]; then
    cp -a -- "$DEST_DIR/$file" "$BACKUP_DIR/$file"
  fi
done

install -m 0755 "$SOURCE_DIR/bin/specter" "$DEST_DIR/.specter.new"
install -m 0755 "$SOURCE_DIR/bin/specter-web" "$DEST_DIR/.specter-web.new"
install -m 0644 "$SOURCE_DIR/bin/specter_ui.html" "$DEST_DIR/.specter_ui.html.new"
install -m 0644 "$SOURCE_DIR/bin/tool_manager.py" "$DEST_DIR/.tool_manager.py.new"
INSTALL_STARTED=1
mv -f -- "$DEST_DIR/.specter.new" "$DEST_DIR/specter"
mv -f -- "$DEST_DIR/.specter-web.new" "$DEST_DIR/specter-web"
mv -f -- "$DEST_DIR/.specter_ui.html.new" "$DEST_DIR/specter_ui.html"
mv -f -- "$DEST_DIR/.tool_manager.py.new" "$DEST_DIR/tool_manager.py"

bash -n "$DEST_DIR/specter"
python3 -m py_compile "$DEST_DIR/specter-web"
COMMITTED=1
trap - ERR
echo "SPECTER v3.0.2-dev terpasang."
echo "Backup lama: $BACKUP_DIR"
echo "Data proyek tidak diubah. Backend yang sedang berjalan tidak direstart."
