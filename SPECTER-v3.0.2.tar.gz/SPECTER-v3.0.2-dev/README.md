# SPECTER v3.0.2-dev — Integrated Tool Manager

SPECTER is a local-first project dashboard and authorized security-assessment helper. This is a development / release-candidate source distribution. Do not label it stable until device-specific ARM64 and browser end-to-end checks have passed.

## Important capability boundary

This build is **not a full automated vulnerability scanner**. The current engine:

- inventories locally installed security tools;
- creates a scan plan and marks it `PLAN_ONLY` (it does not execute the listed tools);
- performs DNS resolution through the system resolver;
- performs one HTTP `HEAD` baseline request for `BUG_BOUNTY` and explicitly authorized `JAILBREAK` projects;
- does not perform SQL injection, XSS, IDOR, LFI, exploitation, privilege escalation, or post-exploitation testing.

Reports are summaries of stored project data and are explicitly marked `NOT INDEPENDENTLY VERIFIED`. A tool being available or a response status being returned is not proof of a vulnerability.

## Modes

1. **BUG_BOUNTY** — requires a scope list. The target hostname must exactly match a hostname in the project's scope file before a scan is queued. Subdomain wildcard expansion is not implied.
2. **AUTOMATED_RESEARCH** — performs local tool inventory/planning and DNS resolution; it does not send the HTTP baseline request.
3. **JAILBREAK** — private lab mode. Use only for assets you own or have explicit permission to test. Project creation requires authorization confirmation and every scan requires the exact confirmation string `I_AUTHORIZE_THIS_SCAN`. This mode does not bypass authorization or add unrestricted exploitation.

## Requirements

- Linux / Debian-based environment
- Bash 4+
- Python 3.10+ (standard library only)
- `curl` and `getent` for the current baseline checks
- `apt-get` for APT-managed tools; `go` for Go-managed tools; Python `venv`/`pip` for Python-managed tools
- Optional security tools are listed in the integrated Tool Manager. Supported APT, Go, and Python tools can be installed/updated; removals are limited to installations recorded as SPECTER-managed. Some tools remain manual-only.
- Installing tools does not execute scans; the engine remains `PLAN_ONLY`.

## Run from extracted folder

```bash
cd SPECTER-v3.0.2-dev
./bin/specter --version
./bin/specter
```

The dashboard binds to `127.0.0.1:8765` by default. Keep it loopback-only; do not expose it to a LAN or the public internet. The backend has no user-account authentication and is intended for a single local operator.

## Install to `/usr/local/bin`

Run as root from the extracted archive:

```bash
sudo ./install.sh
specter --version
specter
```

The installer creates a timestamped backup of any existing `specter`, `specter-web`, `specter_ui.html`, and `tool_manager.py` files before replacing them. It does not restart an existing backend and does not delete project data. For isolated testing, `SPECTER_INSTALL_DIR` and `SPECTER_BACKUP_ROOT` can override the install and backup directories.

## Integrated Tool Manager

Open the dashboard and use **Tool Manager** to refresh inventory or install/update supported tools. Each install/update/remove action requires confirmation. Operations use a fixed allowlist and argument arrays (no shell command construction). APT operations require root; Go tools use the manager's private `tool-manager/bin`; Python tools use per-tool virtual environments. `trivy`, `grype`, `testssl.sh`, and `feroxbuster` are marked manual-only in this build. Remove is enabled only for tools recorded in the SPECTER manifest; tools detected elsewhere on the system are not removed. Review package changes before confirming.

The manager does not start scanners and does not change the `PLAN_ONLY` scan policy. Current catalog: subfinder, dnsx, httpx, katana, gau, nuclei, dalfox, sqlmap, nmap, whatweb, whois, curl, dig, host, nslookup, ffuf, arjun, tlsx, wafw00f, amass, assetfinder, feroxbuster, interactsh-client, testssl.sh, gitleaks, semgrep, trivy, and grype.

## Data location

Default data directory:

```text
/root/specter-v3-data
```

Override it with `SPECTER_DATA_DIR=/path/to/data`. The CLI and backend use the same variable. Job concurrency is limited to 10 queued/running jobs, with at most 2 worker threads.

## Reports and evidence handling

- Private and Shareable reports are generated separately.
- Evidence entries are reduced to metadata (type, detector, filename, line/column, severity, confidence, fingerprint, status, and safe source label). Raw `value`, token, password, key, and other secret-bearing fields from `evidence/evidence.json` are not copied to the dashboard API or either report.
- Shareable reports additionally redact common secret fields and credential patterns in other report data.
- Private report files are written with mode `0644` as requested for this project. Their parent project directory is normally private due to the launcher's `umask 077`; do not move private reports into a publicly readable directory without reviewing their contents.
- Triage and activity data are retained as stored; report generation does not claim to validate findings.

## Optional external AI

If both `SPECTER_AI_API_KEY` and `SPECTER_AI_MODEL` are set, chat context may be sent to `SPECTER_AI_BASE_URL` (default OpenAI-compatible chat completions endpoint). Context includes the target, mode, summary, triage candidates, hosts, and URLs. Do not enable this if those project details must remain local. Without both variables, the local intelligence helper is used.

## Tests

No tests perform external network access. Run:

```bash
python3 -m unittest discover -s tests -v
bash tests/test_engine.sh
bash -n bin/specter
python3 -m py_compile bin/specter-web bin/tool_manager.py
bash tests/test_install.sh  # includes injected-failure rollback test
# On the target device, run the full local smoke suite:
bash tests/device-smoke.sh
```

The local HTTP smoke check should verify `/` returns the dashboard and `/api/tools` returns 28 catalog entries. Browser automation is a separate end-to-end check. The UI inline JavaScript can be syntax-checked with Node.js (optional):

```bash
python3 - <<'PY'
from pathlib import Path
import re
html = Path('bin/specter_ui.html').read_text(encoding='utf-8')
for i, script in enumerate(re.findall(r'<script[^>]*>(.*?)</script>', html, re.S), 1):
    Path(f'/tmp/specter-ui-{i}.js').write_text(script, encoding='utf-8')
PY
for f in /tmp/specter-ui-*.js; do node --check "$f"; done
```

See [ROADMAP.md](ROADMAP.md) for the exact implementation status and remaining work.

## Release notes

This maintenance build is based on the most complete installed v3.0.0 component set in the supplied archive, not a blind merge of timestamped backups. It includes fail-closed mode validation before queue creation, strict Bug Bounty target/scope matching, symlink rejection for the scope file, a bounded job queue, metadata-only secret evidence, broader Shareable report redaction, and portable sibling-path resolution for the engine/UI.

## License

No license choice was supplied with the source archive. Add the project's chosen open-source license before publishing or redistributing this archive publicly.
