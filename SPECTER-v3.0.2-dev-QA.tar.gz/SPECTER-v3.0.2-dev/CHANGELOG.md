# Changelog

## v3.0.1 — 2026-11-08

- Reject unknown project modes before creating a scan job.
- Require Bug Bounty target hostname to appear exactly in the saved scope before project creation and scan queueing.
- Reject missing or symlinked Bug Bounty scope files.
- Bound queued/running jobs to 10; retain a two-worker execution pool.
- Keep raw secret values out of dashboard API evidence metadata and both report profiles.
- Improve Shareable report redaction for camelCase secret keys and JSON-like text.
- Preserve Private Report file mode `0644`; do not apply a restrictive `0600` mode.
- Resolve engine and dashboard UI relative to the backend/CLI install directory; support `SPECTER_DATA_DIR`.
- Add offline backend and engine regression tests.


## v3.0.2-dev — Integrated Tool Manager

- Added allowlisted tool catalog and inventory with path/version/method/ownership metadata.
- Added dashboard install/update/remove actions for APT, Go, and per-tool Python virtualenv installs.
- Removal is restricted to tools recorded in the SPECTER-managed manifest; manual-only tools are not executed by the manager.
- Kept scan engine in `PLAN_ONLY`; Tool Manager does not launch scanners.
- Installer now backs up and deploys `tool_manager.py`.
- Requires further ARM64 device and browser end-to-end testing before release.


### QA hardening after initial dev archive

- Reject symlinked data roots and managed binary / virtualenv paths.
- Enforce private Tool Manager directories and atomically replace the manifest with mode 0600.
- Prevent installing over untracked binaries inside the manager directory.
- Recreate a missing managed Python virtualenv during Update and tolerate an already-missing venv during Remove.
- Replace Amass `@master` with `@latest`.
- Add symlink, storage-permission, and installer rollback regression tests.
- Stable promotion remains pending ARM64 device QA and interactive browser end-to-end testing.
