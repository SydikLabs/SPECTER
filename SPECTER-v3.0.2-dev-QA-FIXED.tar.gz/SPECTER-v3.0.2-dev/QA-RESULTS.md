# SPECTER v3.0.2-dev QA results

Tested in the provided build environment on 2026-11-10.

## Passed

- Python unit tests: 20/20.
- Core engine regression test: PASS.
- Bash syntax check: PASS.
- Python compile checks (`specter-web`, `tool_manager.py`): PASS.
- Installer success-path test: PASS.
- Installer failure-injection rollback test: PASS; all four pre-existing installed files were restored after a simulated first-rename failure.
- Inline dashboard JavaScript syntax (`node --check`): PASS.
- Local HTTP smoke: `/` returned HTTP 200; `/api/health` returned version 3.0.2-dev; `/api/tools` returned 28 entries.
- Tool Manager allowlist rejects an unknown tool: PASS.
- APT install/remove control-flow tests use mocked package-manager calls; no real packages were installed or removed during QA.
- Symlink and storage-permission regression tests: PASS.

## Not yet verified — stable promotion blocked

- Build environment architecture is `x86_64`, not the target Android/KaliDroid ARM64 environment. Go binary compatibility and actual APT package availability must be checked on-device.
- Interactive browser end-to-end testing did not complete: headless Chromium timed out in this environment while reporting missing D-Bus. The dashboard HTML and API were independently verified over HTTP, and JavaScript syntax passed.
- Real network-backed Go/Python package installation and upgrade were not run. APT flow was mocked to avoid changing the QA host.
- Four catalog entries remain manual-only: `feroxbuster`, `testssl.sh`, `trivy`, and `grype`.
- Scan execution remains `PLAN_ONLY`; Tool Manager does not make the scanner execute its plan.

## Release decision

**QA candidate only — do not label stable yet.** Run `bash tests/device-smoke.sh` on the target ARM64 device, then perform a real dashboard interaction and at least one controlled install/update/remove cycle for a disposable supported tool before stable promotion.


### Tool Manager install timeout fix (QA patch)

- Removed the default 900-second wall-clock timeout from Tool Manager command execution.
- Removed the explicit 600-second timeout from `apt-get update`.
- Install/update/remove commands now wait for the package or tool process to finish; version-probe timeout remains unchanged.
- Scan-engine timeout behavior was not changed.
- Validation: Python compile checks passed; full unittest suite passed (21 tests).
- No real network-backed installation was run as part of this QA validation.
