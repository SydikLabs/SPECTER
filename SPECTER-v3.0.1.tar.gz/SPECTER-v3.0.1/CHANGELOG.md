# Changelog

## v3.0.1 — 2026-11-08

- Reject unknown project modes before creating a scan job.
- Require Bug Bounty target hostname to appear exactly in the saved scope before project creation and scan queueing.
- Reject missing or symlinked Bug Bounty scope files.
- Bound queued/running jobs to 10; retain a two-worker execution pool.
- Keep raw secret values out of dashboard API evidence metadata and both report profiles.
- Improve Shareable report redaction for camelCase secret keys and JSON-like text.
- Preserve Private Report file mode `0644`; do not apply a restrictive `0600` mode.
- Resolve engine and dashboard UI relative to the backend/CLI install directory; support `SPECTER_DATA_DIR`.
- Add offline backend and engine regression tests.

## v3.0.1 — Native execution update

- Removed Tool Manager and PLAN_ONLY planner from CLI, backend API, dashboard, and documentation.
- Added ordered native execution steps for the 28 system tools; outputs and per-tool status are stored in each project's `assets/tools/` directory.
- Added bounded command execution, conservative request rates, mode-based skips, and explicit prerequisite skips for SQLMap/OAST and wordlist-dependent checks.
- Prefer `/root/go/bin` in PATH so native ProjectDiscovery executables are selected ahead of similarly named distro/Python commands.
- Added an offline mocked-tool regression test for the native pipeline.
