# SPECTER v3.0.1 — Audited Maintenance Build

SPECTER is a local-first project dashboard and authorized security-assessment helper. This archive is a cleaned and repaired source distribution assembled from the uploaded v3 snapshots and the installed v3.0.0 CLI, backend, and UI.

## Native tool execution and capability boundary

The engine calls the system-installed executables directly through `PATH`; it does not install, update, wrap, or manage tools. The scan pipeline has 28 ordered tool steps and stores per-tool output in `assets/tools/` inside the selected project. Missing tools are recorded as `MISSING`; tools that require additional input or a separate authorization step are recorded as `SKIPPED` with a reason.

The pipeline is bounded (per-command timeout and conservative request rates). It does not claim that every step will run in every mode: Automated Research skips active web/network checks; wordlist-based checks need a readable wordlist; SQL injection checks and OAST sessions are intentionally not started automatically. Nuclei is limited to critical, high, and medium severities. A tool result is only an assessment signal, not proof of a vulnerability.

Reports remain summaries of stored project data and are explicitly marked `NOT INDEPENDENTLY VERIFIED`. The engine does not perform unrestricted exploitation, privilege escalation, or post-exploitation.

## Modes

1. **BUG_BOUNTY** — requires a scope list. The target hostname must exactly match a hostname in the project's scope file before a scan is queued. Subdomain wildcard expansion is not implied.
2. **AUTOMATED_RESEARCH** — runs passive asset discovery and basic DNS/registration lookups only; active web and vulnerability checks are skipped.
3. **JAILBREAK** — private lab mode. Use only for assets you own or have explicit permission to test. Project creation requires authorization confirmation and every scan requires the exact confirmation string `I_AUTHORIZE_THIS_SCAN`. This mode does not bypass authorization or add unrestricted exploitation.

## Requirements

- Linux / Debian-based environment
- Bash 4+
- Python 3.10+ (standard library only)
- `curl` and `getent` for the current baseline checks
- The 28 native tools you have installed are invoked directly by the scan engine. Ensure the intended executables are on `PATH`; SPECTER does not install or update them.
- Set `SPECTER_WORDLIST=/path/to/wordlist` to enable the wordlist-dependent content discovery steps.

## Run from extracted folder

```bash
cd SPECTER-v3.0.1
./bin/specter --version
./bin/specter
```

The dashboard binds to `127.0.0.1:8765` by default. Keep it loopback-only; do not expose it to a LAN or the public internet. The backend has no user-account authentication and is intended for a single local operator.

## Install to `/usr/local/bin`

Run as root from the extracted archive:

```bash
sudo ./install.sh
specter --version
specter
```

The installer creates a timestamped backup of any existing `specter`, `specter-web`, and `specter_ui.html` files before replacing them. It does not restart an existing backend and does not delete project data. For isolated testing, `SPECTER_INSTALL_DIR` and `SPECTER_BACKUP_ROOT` can override the install and backup directories.

## Data location

Default data directory:

```text
/root/specter-v3-data
```

Override it with `SPECTER_DATA_DIR=/path/to/data`. The CLI and backend use the same variable. Job concurrency is limited to 10 queued/running jobs, with at most 2 worker threads. Each project stores tool output under `assets/tools/`.

## Reports and evidence handling

- Private and Shareable reports are generated separately.
- Evidence entries are reduced to metadata (type, detector, filename, line/column, severity, confidence, fingerprint, status, and safe source label). Raw `value`, token, password, key, and other secret-bearing fields from `evidence/evidence.json` are not copied to the dashboard API or either report.
- Shareable reports additionally redact common secret fields and credential patterns in other report data.
- Private report files are written with mode `0644` as requested for this project. Their parent project directory is normally private due to the launcher's `umask 077`; do not move private reports into a publicly readable directory without reviewing their contents.
- Triage and activity data are retained as stored; report generation does not claim to validate findings.

## Optional external AI

If both `SPECTER_AI_API_KEY` and `SPECTER_AI_MODEL` are set, chat context may be sent to `SPECTER_AI_BASE_URL` (default OpenAI-compatible chat completions endpoint). Context includes the target, mode, summary, triage candidates, hosts, and URLs. Do not enable this if those project details must remain local. Without both variables, the local intelligence helper is used.

## Tests

No tests perform external network access. Run:

```bash
python3 -m unittest discover -s tests -v
bash tests/test_engine.sh
bash tests/test_native_pipeline.sh
bash -n bin/specter
python3 -m py_compile bin/specter-web
```

The UI inline JavaScript can be syntax-checked with Node.js (optional):

```bash
python3 - <<'PY'
from pathlib import Path
import re
html = Path('bin/specter_ui.html').read_text(encoding='utf-8')
for i, script in enumerate(re.findall(r'<script[^>]*>(.*?)</script>', html, re.S), 1):
    Path(f'/tmp/specter-ui-{i}.js').write_text(script, encoding='utf-8')
PY
for f in /tmp/specter-ui-*.js; do node --check "$f"; done
```

See [ROADMAP.md](ROADMAP.md) for the exact implementation status and remaining work.

## Release notes

This maintenance build is based on the most complete installed v3.0.0 component set in the supplied archive, not a blind merge of timestamped backups. It includes fail-closed mode validation before queue creation, strict Bug Bounty target/scope matching, symlink rejection for the scope file, a bounded job queue, metadata-only secret evidence, broader Shareable report redaction, and portable sibling-path resolution for the engine/UI.

## License

No license choice was supplied with the source archive. Add the project's chosen open-source license before publishing or redistributing this archive publicly.
