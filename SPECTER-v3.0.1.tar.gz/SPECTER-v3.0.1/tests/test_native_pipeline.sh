#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
export SPECTER_DATA_DIR="$TMP/data"
export SPECTER_MOCK_LOG="$TMP/invoked.log"
export SPECTER_WORDLIST="$TMP/wordlist.txt"
mkdir -p "$TMP/mockbin"
printf 'admin\n' > "$SPECTER_WORDLIST"
: > "$SPECTER_MOCK_LOG"

for tool in subfinder dnsx httpx katana gau nuclei dalfox nmap whatweb whois curl dig host nslookup ffuf arjun tlsx wafw00f amass assetfinder gitleaks semgrep feroxbuster trivy grype testssl.sh; do
  cat > "$TMP/mockbin/$tool" <<'MOCK'
#!/usr/bin/env bash
set -e
name="$(basename "$0")"
printf '%s\n' "$name" >> "$SPECTER_MOCK_LOG"
while (($#)); do
  case "$1" in
    -o|-oN|-oJ|--output|--report-path)
      shift
      if (($#)); then printf 'https://example.com/?q=test\n' > "$1"; fi
      ;;
    *) ;;
  esac
  shift || true
done
case "$name" in
  subfinder|assetfinder|amass) printf 'example.com\n' ;;
  gau) printf 'https://example.com/?q=test\n' ;;
esac
MOCK
  chmod +x "$TMP/mockbin/$tool"
done

PATH="$TMP/mockbin:/usr/bin:/bin" "$BASE/bin/specter" --engine-create 'Native QA' 'https://example.com' BUG_BOUNTY UNCONFIRMED 'example.com' >/dev/null
PROJECT="$(find "$SPECTER_DATA_DIR/projects" -mindepth 1 -maxdepth 1 -type d -name 'native-qa-*' -print -quit)"
NAME="$(basename "$PROJECT")"
PATH="$TMP/mockbin:/usr/bin:/bin" "$BASE/bin/specter" --engine-scan "$NAME" UNCONFIRMED >/dev/null

for tool in subfinder dnsx httpx katana gau nuclei dalfox nmap whatweb whois curl dig host nslookup ffuf arjun tlsx wafw00f amass assetfinder gitleaks semgrep feroxbuster trivy grype testssl.sh; do
  grep -Fx "$tool" "$SPECTER_MOCK_LOG" >/dev/null || { echo "FAIL: $tool was not invoked" >&2; exit 1; }
done
for tool in sqlmap interactsh-client; do
  grep -F "STATUS=SKIPPED" "$PROJECT/assets/tools/$tool.txt" >/dev/null || { echo "FAIL: $tool skip reason missing" >&2; exit 1; }
done

test -s "$PROJECT/assets/tools/nuclei.txt"
test -s "$PROJECT/assets/tools/ffuf.txt"
test -s "$PROJECT/assets/tools/trivy.txt"
echo 'NATIVE_PIPELINE_TESTS=PASS'
