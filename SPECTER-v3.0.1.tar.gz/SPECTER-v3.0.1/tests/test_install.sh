#!/usr/bin/env bash
set -Eeuo pipefail
BASE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin" "$TMP/backups"
printf 'OLD CLI\n' > "$TMP/bin/specter"
printf 'OLD WEB\n' > "$TMP/bin/specter-web"
printf 'OLD UI\n' > "$TMP/bin/specter_ui.html"
SPECTER_INSTALL_DIR="$TMP/bin" SPECTER_BACKUP_ROOT="$TMP/backups" \
  "$BASE/install.sh" >/dev/null

"$TMP/bin/specter" --version | grep -Fx 'SPECTER 3.0.1' >/dev/null
python3 -m py_compile "$TMP/bin/specter-web"
test -s "$TMP/bin/specter_ui.html"
BACKUP="$(find "$TMP/backups" -mindepth 1 -maxdepth 1 -type d -print -quit)"
test -n "$BACKUP"
grep -Fx 'OLD CLI' "$BACKUP/specter" >/dev/null
grep -Fx 'OLD WEB' "$BACKUP/specter-web" >/dev/null
grep -Fx 'OLD UI' "$BACKUP/specter_ui.html" >/dev/null

echo 'INSTALLER_TESTS=PASS'
